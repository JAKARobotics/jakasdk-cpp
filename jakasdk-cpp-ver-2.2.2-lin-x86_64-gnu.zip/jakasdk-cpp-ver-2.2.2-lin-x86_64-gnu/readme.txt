Jaka SDK Version 2.2.1

Documentation can be found at: http://jaka.com/docs/en/

Installation instructions:

Refer to the documentation at: https://www.jaka.com/docs/en/ for detailed installation instructions under linux.